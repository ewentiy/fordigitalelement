let slot_screen = document.getElementById("slot-screen");
let reel = document.getElementsByClassName("reel");
let reels = document.getElementsByClassName("reels");
let stop_btn = document.getElementsByClassName("stop-btn");
let start_btn = document.getElementById("start-btn");


let sec = 100; //скорость
let stopReelFlag = [];
let reelCounts = [];
let slotFrameHeight;
let slotReelsHeight;
let slotReelitemHeight;
let slotReelStartHeight;

let numbers = [4200, 4300, 4400, 4600, 4700, 4800, 4900];

// // Выбор случайного числа из массива
// let randomIndex = Math.floor(Math.random() * numbers.length);
// let randomNumber = numbers[randomIndex];
// Math.random() * 1000;
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }
  shuffleArray(numbers);

  let randomIndex = Math.floor(Math.random() * numbers.length);
let randomNumber = numbers[randomIndex];

let slot ={
    init:function(){
        stopReelFlag[0] = stopReelFlag[1] = stopReelFlag[2] = stopReelFlag[3] = stopReelFlag[4] = false;
        reelCounts[0] = reelCounts[1] = reelCounts[2] = reelCounts[3] =  reelCounts[4] = 0;
    },

    spinTime:function(){
        
    },

    start:function(){
        slot.init();
        for(let index = 0 ; index < 5 ; index++){
            slot.animation(index);
        }
    },


    stop:function(i){
        stopReelFlag[i] = true
        if(stopReelFlag[0] && stopReelFlag[1] && stopReelFlag[2] ){
            start_btn.removeAttribute("disabled");
        }
    },



    resetlocationInfo: function() {
        slotFrameHeight = slot_screen.offsetHeight;
        slotReelsHeight = reels[0].offsetHeight;
        slotReelitemHeight = reel[0].offsetHeight;
        slotReelStartHeight = -slotReelsHeight;
        slotReelStartHeight += slotFrameHeight - (slotFrameHeight / 2) + slotReelitemHeight * 3 / 2; // Учитывается 5 барабанов здесь
        for (let i = 0; i < reels.length; i++) {
            reels[i].style.top = String(slotReelStartHeight) + "px";
        }
    },
    animation: function(index) {
        if (reelCounts[index] >= 10) {
            reelCounts[index] = 0;
        }
        $(".reels").eq(index).animate({
            "top": slotReelStartHeight + (reelCounts[index] * slotReelitemHeight)
        }, {
            duration: sec,
            easing: "linear",
            complete: function() {
                if (stopReelFlag[index]) {
                    return;
                }
                reelCounts[index]++;
                slot.animation(index);

                // Возвращаем барабан к начальной позиции после завершения анимации
                if (reelCounts[index] >= 10) {
                    $(".reels").eq(index).css("top", slotReelStartHeight);
                }
            }
        });
    },
};
window.onload = function(){

    slot.init();
    slot.resetlocationInfo();
    start_btn.addEventListener("click",function(e){
        e.target.setAttribute("disabled", true);
        slot.start();

        setTimeout(function(){
            shuffleArray(numbers);
            slot.stop(0);
            slot.stop(1);
            slot.stop(2);
            slot.stop(3);
            slot.stop(4);
            e.target.removeAttribute("disabled");
        }, randomNumber); 
    });
}